# code-reviews-commit-files.js history

## 2026-11-18 — Automatic commit-file list design baseline
- Proposed scope: code-reviews-commit-files.js participates in the bounded, read-only first-parent metadata flow and inline current-source links described by automatic-commit-file-list-v1.md.
- Why: expose changed files without entering Code Review or fetching patches/content during timeline rendering; preserve existing reviewer and file-viewer contracts.
- Design validation: patch applicability and JavaScript syntax are checked in the retained design receipt. Application builds, tests and installed UI/performance checks are not claimed at design time. The implementation batch must append its actual validation results before committing.

## 2026-11-18 — Implement approved v1
- Implemented visible names-only enrichment, shared bounded promise/result memo, eight-file server paging, explicit retry and current-source provider links. Commit/review controls remain intact; no polling, patch/blob requests, new styles or collapsed content.
- Validation: Release WebHarness build succeeded (two existing assembly-conflict warnings); recorded full C# run 193 passed / 5 failed out of 198. All five failures were reproduced against unchanged baseline 209f1b6 and require a configured sessions database in existing artifact-reader fixtures. All four new metadata tests passed. JavaScript regression suites: 43/43 passed, including six new enhancer cases; syntax and diff checks passed. Installed staging acceptance is recorded separately after activation.

## 2026-11-18 — Compact file disclosure, closed by default
- Matt explicitly requested a prettier file block collapsed by default, overriding the no-collapse UI default for this block. Reuse the shared theme button, badge, spacing and border classes; add a chevron, total-file count and file icons. No custom CSS or core change.
- Keep the disclosure shell and toggle independent of asynchronous content rendering so loading, retry and pagination preserve the current open/closed choice. Use native button semantics with unique aria-controls and aria-expanded. Metadata bounds, viewport trigger, request sharing and viewer routing are unchanged.
- Validation: JavaScript syntax and all 45 Node tests passed, including eight enhancer cases for initial collapse, count, open/close, preserved paging state, cached reopen, late responses, empty/error states and existing review regressions. Release WebHarness build passed with 25 dependency warnings; targeted TimelineCommitFilesTests passed. Full C# suite was not rerun; its five documented baseline fixture failures remain an unmet original acceptance criterion, not waived. Installed staging visual acceptance follows package activation.

## 2026-11-18 — Link non-code files through the shared viewer
- Matt pointed out that all six files in the example can be opened in the source viewer, not only JavaScript. The initial implementation incorrectly used IsCode as a navigation capability check; the shared presentation registry already accepts generic text files.
- Remove that IsCode gate from link creation. Keep it for icons only. Let the existing shared registry select the viewer for Markdown, JSON, project files and code; preserve C# viewer integration, deleted-file exclusion, rename labels, safe text, paging and the collapsed default. Unsupported file types still have no invented destination.
- Validation: syntax and diff checks passed; nine enhancer cases and 37 review/semantic-reference cases passed (46 total), including an integration test against the actual shared provider registry for Markdown, JSON, csproj, JavaScript, C#, renamed/deleted Markdown and unsupported PNG. Release build passed with 25 dependency warnings; all four targeted C# metadata tests passed. Full C# suite was not rerun; original five baseline fixture failures remain unresolved. Installed staging validation is recorded separately.

